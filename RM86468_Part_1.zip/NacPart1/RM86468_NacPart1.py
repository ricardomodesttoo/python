
import cv2
import numpy as np

cap = cv2.VideoCapture("q1.mp4") 
template = cv2.imread("carta3.png", cv2.IMREAD_GRAYSCALE)
w, h = template.shape[::-1]

detectado = False

while True:
    detectado = False
    res, frame = cap.read()   
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    if not res:
        break

    res = cv2.matchTemplate(gray_frame, template, cv2.TM_CCOEFF_NORMED)
    loc = np.where(res >= 0.46)

    for pt in zip(*loc[::-1]):
        cv2.rectangle(frame, pt, (pt[0] + w, pt[1] + h), (0, 255, 0), 2)
        detectado = True

    if (detectado == True):    
        cv2.putText(frame, 'Detectado!', (95,35), 1, 3, (0,255,0),2)    

    else:    
        cv2.putText(frame, 'Não Detectado!', (95,35), 1, 3, (0,255,0),2)    

    cv2.imshow("Frame", frame)

    key = cv2.waitKey(1) & 0xFF
    if key == 27:
        break

cap.release()
cv2.destroyAllWindows()