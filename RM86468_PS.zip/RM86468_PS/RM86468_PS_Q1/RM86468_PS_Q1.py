import cv2
import imutils
import numpy as np

cap = cv2.VideoCapture("q1A.mp4")

cap.set(3, 320)
cap.set(4, 320)


while True:
    ret, frame = cap.read() 
	
    if not ret:
        break

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # --- Amarelo ---
    amarillo_osc = np.array([25, 70, 120])
    amarillo_cla = np.array([30, 255, 255])

    # --- Vermelho ---
    rojo_osc = np.array([0, 50, 120])
    rojo_cla = np.array([10, 255, 255])

    # --- Verde ---
    verde_osc = np.array([40, 70, 80])
    verde_cla = np.array([70, 255, 255])

    # --- Azul ---
    azul_osc = np.array([90, 60, 0])
    azul_cla = np.array([121, 255, 255])

    cara1 = cv2.inRange(hsv, amarillo_osc, amarillo_cla)
    cara2 = cv2.inRange(hsv, rojo_osc, rojo_cla)
    cara3 = cv2.inRange(hsv, verde_osc, verde_cla)
    cara4 = cv2.inRange(hsv, azul_osc, azul_cla)

    cnts1 = cv2.findContours(cara1, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    cnts1 = imutils.grab_contours(cnts1)

    cnts2 = cv2.findContours(cara2, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    cnts2 = imutils.grab_contours(cnts2)

    cnts3 = cv2.findContours(cara3, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    cnts3 = imutils.grab_contours(cnts3)

    cnts4 = cv2.findContours(cara4, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    cnts4 = imutils.grab_contours(cnts4)

    colisao = 0

    for c in cnts1:
        area1 = cv2.contourArea(c)
        
        if area1>5000:
            cv2.drawContours(frame, [c], -1, (30, 255, 255), 3)
            M = cv2.moments(c)
            cx = int(M["m10"]/M["m00"])
            cy = int(M["m01"]/M["m00"])
            cv2.circle(frame, (cx, cy), 7, (255, 255, 255), -1)
            cv2.putText(frame, "Amarelo", (cx-20, cy-20), cv2.FONT_ITALIC, 2, (255, 255, 255), 2)
  
    for c in cnts2:
        area2 = cv2.contourArea(c)              
        if area2>5000:
            cv2.drawContours(frame, [c], -1, (0, 255, 0), 3)
            M = cv2.moments(c)
            cx = int(M["m10"]/M["m00"])
            cy = int(M["m01"]/M["m00"])
            cv2.circle(frame, (cx, cy), 7, (0, 255, 255), -1)
            #cv2.putText(frame, "Vermelho", (cx-20, cy-20), cv2.FONT_ITALIC, 2, (255, 255, 255), 2)            
            colisao = area2

    for c in cnts3:
        area3 = cv2.contourArea(c)
        
        if area3>5000:
            cv2.drawContours(frame, [c], -1, (30, 255, 255), 3)
            M = cv2.moments(c)
            cx = int(M["m10"]/M["m00"])
            cy = int(M["m01"]/M["m00"])
            cv2.circle(frame, (cx, cy), 7, (255, 255, 255), -1)
            cv2.putText(frame, "Verde", (cx-20, cy-20), cv2.FONT_ITALIC, 2, (255, 255, 255), 2)

    for c in cnts4:
        area4 = cv2.contourArea(c)
        
        if area4>5000:
            
            M = cv2.moments(c)
            cx = int(M["m10"]/M["m00"])
            cy = int(M["m01"]/M["m00"])            
            #print("Azul",area4)
            #print("Colisao", colisao)
            
            if area4 >= 14957.0 and colisao <= 98361.5:
                cv2.putText(frame, 'COLISAO DETECTADA!', (95,35), 1, 3, (0,255,0),2)

            elif area4 <= 21071.0 and colisao >= 98943.0:
                if area4 >= 20506.0 and colisao <= 98970.0:
                    cv2.putText(frame, 'PASSOU BARREIRA!', (95,35), 1, 3, (0,255,0),2)

    # Exibe resultado
    cv2.imshow("Feed", frame)

    # Wait for key 'ESC' to quit
    key = cv2.waitKey(1) & 0xFF
    if key == 27:
        break

# That's how you exit
cap.release()
cv2.destroyAllWindows()