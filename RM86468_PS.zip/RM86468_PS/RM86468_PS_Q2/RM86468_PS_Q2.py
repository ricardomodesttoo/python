
import cv2
import numpy as np

cap = cv2.VideoCapture("q2.mp4") 

template1 = cv2.imread("CartaX1.png", cv2.IMREAD_GRAYSCALE)
w, h = template1.shape[::-1]


template2 = cv2.imread("CartaX2_1.png", cv2.IMREAD_GRAYSCALE)
w, h = template2.shape[::-1]


template3 = cv2.imread("CartaX3_1.png", cv2.IMREAD_GRAYSCALE)
w, h = template3.shape[::-1]


template4 = cv2.imread("CartaX4_7.png", cv2.IMREAD_GRAYSCALE)
w, h = template4.shape[::-1]


template5 = cv2.imread("CartaX5.png", cv2.IMREAD_GRAYSCALE)
w, h = template5.shape[::-1]

detectado = False

#vermelhas
asOuro = 0
reiOuro = 0
seteOuro = 0
totalVermelhas = 0

#pretas
dezEspada = 0
reiEspada = 0
totalPretas = 0

while True:
    detectado = False
    res, frame = cap.read()       

    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    #gray_frame2 = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    if not res:
        break

    res = cv2.matchTemplate(gray_frame, template1, cv2.TM_CCOEFF_NORMED)
    loc1 = np.where(res >= 0.5)

    res = cv2.matchTemplate(gray_frame, template2, cv2.TM_CCOEFF_NORMED)
    loc2 = np.where(res >= 0.56)

    res = cv2.matchTemplate(gray_frame, template3, cv2.TM_CCOEFF_NORMED)
    loc3 = np.where(res >= 0.9)

    res = cv2.matchTemplate(gray_frame, template4, cv2.TM_CCOEFF_NORMED)
    loc4 = np.where(res >= 0.45)

    res = cv2.matchTemplate(gray_frame, template5, cv2.TM_CCOEFF_NORMED)
    loc5 = np.where(res >= 0.35)

    asOuro = 0
    reiOuro = 0
    seteOuro = 0
    totalVermelhas = 0

    dezEspada = 0
    reiEspada = 0
    totalPretas = 0

    #Aas de ouro
    for pt in zip(*loc1[::-1]):
        cv2.rectangle(frame, pt, (pt[0] + w, pt[1] + h), (0,0,255), 2)
        asOuro = 1

    #Rei de Ouro
    for pt in zip(*loc2[::-1]):
        cv2.rectangle(frame, pt, (pt[0] + w, pt[1] + h), (0,0,255), 2)
        reiOuro = 1
    
    #SeteOuro
    for pt in zip(*loc3[::-1]):
        cv2.rectangle(frame, pt, (pt[0] + w, pt[1] + h), (0,0,255), 2)
        seteOuro = 1

    #ReiEspada
    for pt in zip(*loc4[::-1]):
        cv2.rectangle(frame, pt, (pt[0] + w, pt[1] + h), (255,0,0), 2)
        dezEspada = 1

    #ReiEspada
    for pt in zip(*loc5[::-1]):
        cv2.rectangle(frame, pt, (pt[0] + w, pt[1] + h), (0,255,0), 2)
        reiEspada = 1

    totalVermelhas = seteOuro + reiOuro + asOuro
    totalPretas = dezEspada + reiEspada

    cv2.putText(frame, 'Cartas Vermelhas: ' + str(totalVermelhas) + ' Vs Cartas Pretas: ' + str(totalPretas), (95,35), 1, 3, (0,255,0),2)
    cv2.imshow("Frame", frame)

    #cv2.imshow("Cinza", gray_frame)

    key = cv2.waitKey(1) & 0xFF
    if key == 27:
        break

cap.release()
cv2.destroyAllWindows()